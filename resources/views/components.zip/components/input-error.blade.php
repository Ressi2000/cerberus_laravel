@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge([
        'class' =>
            'text-sm text-red-600 dark:text-red-400 space-y-1 mt-1 transition-colors duration-300'
    ]) }}>
        @foreach ((array) $messages as $message)
            <li>{{ $message }}</li>
        @endforeach
    </ul>
@endif
